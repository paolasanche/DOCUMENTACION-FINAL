PAO =======

DB_HOST: 82.180.174.154
DB_USER: u304056163_joel
DB_NAME: u304056163_zapatosmajodb
DB_PASS: Epx34uk_3RDiKmy

FTP

host: 82.180.174.173
port: 21
user: u304056163
pass: Epx34uk_3RDiKmy

SSH===

command bash: ssh -p 65002 u304056163@82.180.174.154
port: 65002
user: u304056163
pass: Epx34uk_3RDiKmy

MAIL===

smtp.hostinger.com	
465
support@zapatosmajo.online