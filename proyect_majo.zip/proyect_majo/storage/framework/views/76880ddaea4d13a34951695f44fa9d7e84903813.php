 <html>
<head>
    <title>edicion de cliente</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.0.0-alpha/css/bootstrap.css" rel="stylesheet">
</head>
<body>
  
<div class="container">
    

 
     <div class="row">
    <div class="col-lg-12 margin-tb">
        <div class="pull-left">
            <h2>Edit Client</h2>
        </div>
        <div class="pull-right">
            <a class="btn btn-primary" href="<?php echo e(route('productos.index')); ?>"> Back</a>
        </div>
    </div>
  </div>
  
  <?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <strong>Whoops!</strong> There were some problems with your input.<br><br>
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
  <?php endif; ?>
  <form action="<?php echo e(route('productos.update', ['producto' => $producto->id])); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>
  
     <div class="row">
  
  
  
  
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>name:</strong>
                <input type="text" name="name" value="<?php echo e(old('name') ?? $producto->name); ?>" class="form-control" placeholder="name">
            </div>
        </div>
  
  
  
  
  
  
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Tamaño:</strong>
                <input type="text" name="tamano" value="<?php echo e(old('tamano') ?? $producto->tamano); ?>" class="form-control" placeholder="tamano">
            </div>
        </div>
  







  <div class="col-xs-12 col-sm-12 col-md-12">
    <div class="form-group">
        <strong>Descripcion:</strong>
        <input type="text" name="descripcion" value="<?php echo e(old('descripcion') ?? $producto->descripcion); ?>" class="form-control" placeholder="descripcion">
    </div>
</div>






<div class="col-xs-12 col-sm-12 col-md-12">
   <div class="form-group">
        <strong>price:</strong>
        <input type="number" name="price" value="<?php echo e(old('price') ?? $producto->price); ?>" class="form-control" placeholder="price">
   </div>
</div>



<div class="col-xs-12 col-sm-12 col-md-12 text-center">
  <button type="submit" class="btn btn-primary">Submit</button>
</div>
</div>

</form>

</div>
   
</body>
</html>

<?php /**PATH C:\xampp\htdocs\proyect_majo\resources\views/productos/edit.blade.php ENDPATH**/ ?>