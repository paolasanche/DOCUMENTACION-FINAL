<html>
<head>
    <title>edicion de cliente</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.0.0-alpha/css/bootstrap.css" rel="stylesheet">
</head>
<body>
  
<div class="container">
    

 
     <div class="row">
    <div class="col-lg-12 margin-tb">
        <div class="pull-left">
            <h2>Edit Client</h2>
        </div>
        <div class="pull-right">
            <a class="btn btn-primary" href="<?php echo e(route('clientes.index')); ?>"> Back</a>
        </div>
    </div>
  </div>
  
  <?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <strong>Whoops!</strong> There were some problems with your input.<br><br>
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
  <?php endif; ?>
  <form action="<?php echo e(route('clientes.update', ['cliente' => $cliente->id])); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>
  
     <div class="row">
  
  
  
  
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Nombre:</strong>
                <input type="text" name="nombre_cliente" value="<?php echo e(old('nombre_cliente') ?? $cliente->nombre_cliente); ?>" class="form-control" placeholder="nombre_cliente">
            </div>
        </div>
  
  
  
  
  
  
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Telefono:</strong>
                <input type="number" name="telefono_cliente" value="<?php echo e(old('telefono_cliente') ?? $cliente->telefono_cliente); ?>" class="form-control" placeholder="telefono_cliente">
            </div>
        </div>
  







  <div class="col-xs-12 col-sm-12 col-md-12">
    <div class="form-group">
        <strong>Correo:</strong>
        <input type="email" name="correo_cliente" value="<?php echo e(old('correo_cliente') ??  $cliente->correo_cliente); ?>" class="form-control" placeholder="correo_cliente">
    </div>
</div>






<div class="col-xs-12 col-sm-12 col-md-12">
   <div class="form-group">
        <strong>Edad:</strong>
        <input type="number" name="edad_cliente" value="<?php echo e(old('edad_cliente') ??  $cliente->edad_cliente); ?>" class="form-control" placeholder="edad_cliente">
   </div>
</div>








<div class="col-xs-12 col-sm-12 col-md-12">
     <div class="form-group">
         <strong>Direccion:</strong>
         <input type="text" name="direccion_cliente" value="<?php echo e(old('direccion_cliente') ??  $cliente->direccion_cliente); ?>" class="form-control" placeholder="direccion_cliente">
    </div>
</div>









<div class="col-xs-12 col-sm-12 col-md-12">
<div class="form-group">
     <strong>Estado:</strong>
     <input type="text" name="estado_cliente" value="<?php echo e(old('estado_cliente') ??  $cliente->estado_cliente); ?>" class="form-control" placeholder="estado_cliente">
</div>
</div>









<div class="col-xs-12 col-sm-12 col-md-12">
<div class="form-group">
    <strong>Municipio:</strong>
   <input type="text" name="municipio_cliente" value="<?php echo e(old('municipio_cliente') ??  $cliente->municipio_cliente); ?>" class="form-control" placeholder="municipio_cliente">
</div>
</div>









<div class="col-xs-12 col-sm-12 col-md-12">
<div class="form-group">
    <strong>Código Postal:</strong>
    <input type="text" name="codigopostal_cliente" value="<?php echo e(old('codigopostal_cliente') ?? $cliente->codigopostal_cliente); ?>" class="form-control" placeholder="codigopostal_cliente">
</div>
</div>








<div class="col-xs-12 col-sm-12 col-md-12">
     <div class="form-group">
         <strong>Forma de pago:</strong>
         <input type="text" name="forma_pago" value="<?php echo e(old('forma_pago') ??  $cliente->forma_pago); ?>" class="form-control" placeholder="forma_pago">
     </div>
</div>









<div class="col-xs-12 col-sm-12 col-md-12 text-center">
  <button type="submit" class="btn btn-primary">Submit</button>
</div>
</div>

</form>

</div>
   
</body>
</html>

<?php /**PATH C:\xampp\htdocs\proyect_majo\resources\views/clientes/edit.blade.php ENDPATH**/ ?>